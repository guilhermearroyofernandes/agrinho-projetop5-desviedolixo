function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let playerX;
let playerY = 360;
let lixo = [];
let pontos = 0;
let gameOverFlag = false;
let velocidadeLixo = 5;

function setup() {
  createCanvas(600, 400);
  playerX = width / 2;  // Posição inicial do jogador no eixo X
}

function draw() {
  background(100, 200, 100); // Fundo verde (campo)

  // Desenha o personagem
  fill(0, 100, 255);
  ellipse(playerX, playerY, 40, 40); // Corpo do personagem

  // Movimento do jogador
  if (keyIsDown(LEFT_ARROW)) playerX -= 5; // Mover para a esquerda
  if (keyIsDown(RIGHT_ARROW)) playerX += 5; // Mover para a direita

  // Limita o movimento do personagem para que ele não saia da tela
  playerX = constrain(playerX, 20, width - 20);

  // Desenha e movimenta o lixo
  for (let i = lixo.length - 1; i >= 0; i--) {
    let l = lixo[i];
    fill(150);
    rect(l.x, l.y, 20, 20); // Desenha o lixo (caixote ou sacos)

    // Move o lixo para baixo
    l.y += velocidadeLixo;

    // Verifica se o lixo saiu da tela e pontua
    if (l.y > height) {
      lixo.splice(i, 1); // Remove o lixo
      pontos++; // Aumenta o contador de pontos
    }

    // Verifica se houve colisão com o lixo
    if (dist(playerX, playerY, l.x + 10, l.y + 10) < 30) {
      gameOver(); // Se colidir, fim de jogo
      return;
    }
  }

  // Cria novos lixos periodicamente
  if (frameCount % 60 === 0) { // A cada 60 quadros (1 segundo)
    lixo.push(createLixo());
  }

  // Exibe os pontos
  fill(0);
  textSize(20);
  text(`Pontos: ${pontos}`, 20, 30);

  // Se o jogo acabar
  if (gameOverFlag) {
    fill(255, 0, 0);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2 - 20);
    textSize(20);
    text(`Pontos finais: ${pontos}`, width / 2, height / 2 + 20);
    noLoop(); // Para o jogo
  }
}

// Função para criar o lixo em posições aleatórias
function createLixo() {
  let x = random(20, width - 20); // Posição aleatória na largura
  let y = -20; // Começa fora da tela
  return createVector(x, y);
}

// Função para finalizar o jogo
function gameOver() {
  gameOverFlag = true;
  // Aqui você pode adicionar efeitos sonoros ou animações de fim de jogo, se quiser
}